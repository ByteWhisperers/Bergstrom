
-- Script para inserir 120 avaliações realistas
-- Este arquivo é apenas para referência, as avaliações já foram inseridas via código

-- As primeiras 6 avaliações terão imagens de clientes associadas
-- Imagem 1: /lovable-uploads/2ef6f07c-0608-4222-8177-b89c4c9a1cc6.png
-- Imagem 2: /lovable-uploads/79dc90e6-3475-4e78-97ed-f8074bf899cf.png  
-- Imagem 3: /lovable-uploads/bc47914d-f515-4283-b82e-dc9c6c7bd1c8.png
-- Imagem 4: /lovable-uploads/7bd9480e-aea5-4552-b31c-00ebec6f3bc3.png
-- Imagem 5: /lovable-uploads/84ae09e7-aebe-43f5-9d09-0fcd6ec80bfc.png
-- Imagem 6: /lovable-uploads/9be149b8-d8a2-4456-9133-a6bc5d10b9b2.png

-- As avaliações foram criadas com conteúdo realista em português
-- Notas variando entre 4 e 5 estrelas
-- Comentários mencionando qualidade, entrega, atendimento, etc.
